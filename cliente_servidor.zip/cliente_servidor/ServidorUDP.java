/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package cliente_servidor;
 import java.io.IOException;
 import java.net.DatagramPacket;
 import java.net.DatagramSocket;
 import java.net.SocketException;

class Conta{
    public String conta(String req){
        String[] op = req.split(":");
        String operacao = op[0];
        int num1 = Integer.parseInt(op[1]);
        int num2 = Integer.parseInt(op[2]);
        int resultado;
        
        if(null != operacao)switch (operacao) {
            case "soma":
            {
                resultado = num1 + num2;
                String resposta = Integer.toString( resultado );
                return resposta;
            }
            case "multiplica":
            {
                resultado = num1 * num2;
                String resposta = Integer.toString( resultado );
                return resposta;
            }
            case "divide":
            {
                resultado = num1 / num2;
                String resposta = Integer.toString( resultado );
                return resposta;
            }
            default:
                break;
        }
        return "0";
    }
}

 public class ServidorUDP {

    public static void main(String[] args) {
    System.out.println("Servidor UDP online");
    DatagramSocket socket = null;
    try {
        socket = new DatagramSocket(7890);
        byte[] buffer = new byte[1000];
        while (true) {
            DatagramPacket requisicao =
                new DatagramPacket(buffer, buffer.length);

            socket.receive(requisicao);
            System.out.println("Recebi requisicao: "
                + requisicao.getAddress().toString());

            System.out.println(new String (requisicao.getData()));
            
            String req = new String (requisicao.getData());
            
            Conta c = new Conta();
            String resultado= c.conta(req);
            byte[] m = resultado.getBytes();
            int tamanho = resultado.length();

            DatagramPacket resposta = new DatagramPacket(
                m,
                tamanho,
                requisicao.getAddress(),
                requisicao.getPort());
            socket.send(resposta);
            System.out.println("Soma realizada: "
                + new String (resposta.getData()) + "\n");
            }

        }catch (SocketException e) {
            System.out.println("Socket: " + e.getMessage());
        }catch (IOException e) {
            System.out.println("IO: " + e.getMessage());
        }
    }
 }